
import React, { Component } from 'react';
import {
    Text,
    View
} from 'react-native';
import Checkbox from './checkbox';

export default class App extends Component<{}> {

    constructor(props){
        super(props);
        this.state={
            isSelected: true,
            items: ["Test1", "Test2", "Test3", "Test4"],
            selectedVal : ["Test2"],
        }
    }

    onChange = (selectedItem) => {
        if(this.state.selectedVal.indexOf(selectedItem) >= 0){
            //remove
        }else{
            //add
        }
    };

    render() {
        return (
            <View style={{flex:1, marginTop:100, padding:20}}>
                {
                    this.state.items.map((obj,index)=>{
                        return (
                            <Checkbox isSelected={this.state.selectedVal.indexOf(obj) >= 0}
                                      myVal={obj}
                                      key={index}
                                      onChange={this.onChange}/>
                        )
                    })
                }
            </View>
        );
    }
}



import React, { Component } from 'react';
import {
    Text,
    View
} from 'react-native';
import Checkbox from 'react-native-checkbox';

export default class MyCheckbox extends Component<{}> {



    render() {
        return (
            <Checkbox
                label={this.props.myVal}
                checked={this.props.isSelected}
                onChange={(checked) => this.props.onChange(this.props.myVal)}
            />
        );
    }
}


import { StackNavigator, TabNavigator, DrawerNavigator } from 'react-navigation';
import HomeScreen from '../screens/homeScreen'
import SecondScreen from '../screens/secondScreen'
import pageIndicator from '../screens/pageIndicator'

const stack = StackNavigator({
    PageIndicator: { screen: pageIndicator },
    Home: { screen: HomeScreen },
    secondScreen: {screen: SecondScreen}
});
const TabsScreen = TabNavigator({
    Settings: {
        screen: HomeScreen
    },
    Profile: {
        screen: DrawerExample
    }
});

const DrawerExample = DrawerNavigator({
    Inbox: {
        screen: HomeScreen,
    },
    Drafts: {
        screen: SecondScreen,
    },
    Stacks: {
        screen: PageIndicator
    }
}, {
    initialRouteName: 'Drafts',
    contentOptions: {
        activeTintColor: '#e91e63',
    },
});
export default TabsScreen